<?php
header("Location: ../tools");
?>