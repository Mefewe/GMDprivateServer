<?php
require_once "lib/strelokLib.php";
$strelok = new strelokLib();
echo $strelok->lastAuthor();
?>
