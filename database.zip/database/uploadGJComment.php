<?php
include "incl/comments/uploadGJComment.php";
?>