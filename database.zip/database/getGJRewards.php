<?php
include "incl/rewards/getGJRewards.php";
?>