<html>
<body>
prefix - 300 <a href="../stats/topCoins.php">coins</a>
<form action="buy.php" method="post">
username <input type="text" name="username"><br>
prefix name <input type="text" name="prefix"><br>
password <input type="text" name="password"><br>
<input type="submit">
</form>

</body>
</html>