<?php
require_once "../../incl/lib/strelokLib.php";
$gs = new strelokLib();
$gs->TopCoins();
?>
