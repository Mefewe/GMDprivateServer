<html>
    <meta charset="utf-8">
<body>

<form action="../incl/testDel.php" method="post">
userName <input type="text" name="userName"><br>
password <input type="text" name="password"><br>
<input type="submit">
</form>

</body>
</html>