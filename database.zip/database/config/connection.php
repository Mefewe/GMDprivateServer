<?php
$servername = "";
$username = "";
$password = "";
$dbname = "";
$hostl = ""; //write in you host - example - YOURHOST.7m.pl/database      (NO http://)
?>
