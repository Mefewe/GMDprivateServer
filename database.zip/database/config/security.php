<?php
$cloudSaveEncryption = 1; //0 = password string replacement, 1 = cloud save encryption (password dependant)
$sessionGrants = 1; //0 = GJP check is done every time; 1 = GJP check is done once per hour; drastically improves performance, slightly descreases security
?>