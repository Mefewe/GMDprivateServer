<?php
$discordEnabled = 1;
$secret = "FObFlLPdxYELfY3NjMO7QZPh72fFXLRo";
$bottoken = "NzAzODkzNzcyODE5NDk3MDEy.XqVONw.knzAruszWww4gDGw1X8_qHxv1ZU";
?>